package in.wordmug.extvat.Constant;

final public class AppValues {

    public static String BASE_URL = "http://ojasvi.pythonanywhere.com", HOME_URL = BASE_URL + "/home", CHANGE_ROOM = HOME_URL+"/room"
            ,HIST_DAILY = BASE_URL + "/history/day", HIST_WEEKLY = BASE_URL + "/history/week", HIST_MONTHLY = BASE_URL + "/history/month";
}
