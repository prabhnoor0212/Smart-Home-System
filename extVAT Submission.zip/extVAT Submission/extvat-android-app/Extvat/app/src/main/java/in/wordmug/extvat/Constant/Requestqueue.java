package in.wordmug.extvat.Constant;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

/**
 * Created by PRAFULL PC on 20-Dec-17.
 */

public class Requestqueue {

    private static Requestqueue mInstance;

    private static Context context;
    private RequestQueue requestQueue;


    private RequestQueue getRequestQueue()
    {
        if(requestQueue == null)
        {
            requestQueue = Volley.newRequestQueue(context);
        }
        return requestQueue;
    }

    // private constructor
    private Requestqueue(Context context)
    {
        this.context = context;
        requestQueue = getRequestQueue();
    }

    //-------------------------------------PUBLIC FUNCTIONS-----------------------------------------

    public static synchronized Requestqueue getmInstance(Context context)
    {
        if(mInstance == null)
        {
            mInstance = new Requestqueue(context);
        }

        return mInstance;
    }

    public<T> void addToRequestQueue(Request<T> request)            
    {
        getRequestQueue().add(request);
    }


}
