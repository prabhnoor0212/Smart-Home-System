package in.wordmug.extvat.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import in.wordmug.extvat.Constant.AppValues;
import in.wordmug.extvat.Constant.Requestqueue;
import in.wordmug.extvat.R;

public class FragmentHistory extends Fragment {

    GraphView graph;
    TabLayout tabLayout;
    Context context;
    String msgpart="Today";

    TextView histCost, histSavings, bottomSavings, savingsMessage;
    ProgressDialog progressDialog;
    ImageView prevBar,currentBar;


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
        loadHistory(AppValues.HIST_DAILY);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history,container,false);
        graph = view.findViewById(R.id.historyGraph);
        tabLayout = view.findViewById(R.id.historyTabs);
        histCost = view.findViewById(R.id.histCost);
        histSavings = view.findViewById(R.id.histSavings);
        prevBar = view.findViewById(R.id.prevBar);
        currentBar = view.findViewById(R.id.currentBar);
        bottomSavings = view.findViewById(R.id.bottomSavings);
        savingsMessage = view.findViewById(R.id.savingsMessage);

        tabLayout.addTab(tabLayout.newTab().setText("Daily"));
        tabLayout.addTab(tabLayout.newTab().setText("Weekly"));
        tabLayout.addTab(tabLayout.newTab().setText("Monthly"));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition())
                {
                    case 0: loadHistory(AppValues.HIST_DAILY); msgpart = "Today"; break;
                    case 1: loadHistory(AppValues.HIST_WEEKLY);msgpart = "This week"; break;
                    case 2: loadHistory(AppValues.HIST_MONTHLY);msgpart= "This month"; break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
//        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(new DataPoint[] {
//                new DataPoint(0, 1),
//                new DataPoint(1, 5),
//                new DataPoint(2, 3),
//                new DataPoint(3, 2),
//                new DataPoint(4, 4),
//                new DataPoint(5,3),
//                new DataPoint(6,4),
//                new DataPoint(7,7)
//        });
//        series.setColor(getResources().getColor(R.color.colorAccent));
//        series.setDrawDataPoints(true);
//        series.setDataPointsRadius(5);
//        graph.getGridLabelRenderer().setGridColor(Color.parseColor("#9e9e9e"));
//        graph.getGridLabelRenderer().setHorizontalLabelsColor(Color.parseColor("#9e9e9e"));
//        graph.getGridLabelRenderer().setVerticalLabelsColor(Color.parseColor("#9e9e9e"));
//        graph.addSeries(series);
//
//        LineGraphSeries<DataPoint> series1 = new LineGraphSeries<>(new DataPoint[] {
//                new DataPoint(0, 2),
//                new DataPoint(1, 4),
//                new DataPoint(2, 4),
//                new DataPoint(3, 5),
//                new DataPoint(4, 5),
//                new DataPoint(5,3),
//                new DataPoint(6,5),
//                new DataPoint(7,5)
//        });
//        series1.setColor(Color.parseColor("#ff4081"));
//        series1.setDrawDataPoints(true);
//        series1.setDataPointsRadius(5);
//        graph.getGridLabelRenderer().setGridColor(Color.parseColor("#9e9e9e"));
//        graph.getGridLabelRenderer().setHorizontalLabelsColor(Color.parseColor("#9e9e9e"));
//        graph.getGridLabelRenderer().setVerticalLabelsColor(Color.parseColor("#9e9e9e"));
//        graph.addSeries(series1);


        return view;
    }

    private void loadHistory(String URL)
    {
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Loading Data..");
        progressDialog.setCancelable(false);
        progressDialog.show();
        StringRequest str = new StringRequest(StringRequest.Method.GET, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject object = new JSONObject(response);
                            histCost.setText("$"+String.format("%.2f", Float.parseFloat(object.getString("cost"))));
                            histSavings.setText("$"+String.format("%.2f", Float.parseFloat(object.getString("savings"))));
                            bottomSavings.setText("$"+String.format("%.2f", Float.parseFloat(object.getString("savings"))));

                            ArrayList<Float> points = new ArrayList<>();
                            for(int i=0;i<object.getJSONArray("values").length();i++)
                            {
                                points.add(Float.parseFloat(object.getJSONArray("values").getString(i)));
                            }
                            float val1,val2;
                            val1 = object.getJSONObject("compare").getLong("0");
                            val2 = object.getJSONObject("compare").getLong("-1");
                            showDifference(val1,val2);

                            plotGraph(points);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                    }
                }
        ){

        };
        Requestqueue.getmInstance(context.getApplicationContext()).addToRequestQueue(str);
    }

    private void plotGraph(ArrayList<Float> points)
    {
        DataPoint[] dataPoints   = new DataPoint[points.size()];
        float max =0;
        for(int i=0;i<points.size();i++)
        {
            Log.i("Adding point",i+1+"---"+points.get(i));
            dataPoints[i]= new DataPoint(i,points.get(i));
            if(points.get(i)>max){max = points.get(i);}
        }
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(dataPoints);
        series.setColor(getResources().getColor(R.color.colorAccent));
        series.setDrawDataPoints(true);
        series.setDataPointsRadius(5);
        graph.getGridLabelRenderer().setGridColor(Color.parseColor("#9e9e9e"));
        graph.getGridLabelRenderer().setHorizontalLabelsColor(Color.parseColor("#9e9e9e"));
        graph.getGridLabelRenderer().setVerticalLabelsColor(Color.parseColor("#9e9e9e"));
        graph.removeAllSeries();
        graph.getViewport().setYAxisBoundsManual(true);
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setMaxX(23);
        graph.getViewport().setMaxY((int)max+5);
        graph.addSeries(series);
    }


    private void showDifference(float current, float previous)
    {
        float percent;
        if(current>=previous)
        {
            //saved
            percent = previous/current;
            currentBar.setScaleY(1);
            prevBar.setScaleY(percent);
            if(current>previous)
            {
                savingsMessage.setText(msgpart + " you saved significantly more");
            }
            else
            {
                savingsMessage.setText(msgpart + " you didn't saved");
            }
        }
        else
        {
            //lost
            percent = current/previous;
            prevBar.setScaleY(1);
            currentBar.setScaleY(percent);
            savingsMessage.setText(msgpart + " you saved significantly less");
        }
        currentBar.setPivotY(100);
        prevBar.setPivotY(100);
    }

}
