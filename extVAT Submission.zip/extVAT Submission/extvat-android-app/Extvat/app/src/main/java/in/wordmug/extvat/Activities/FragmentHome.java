package in.wordmug.extvat.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatSpinner;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.util.ArrayList;

import in.wordmug.extvat.Constant.AppValues;
import in.wordmug.extvat.Constant.Requestqueue;
import in.wordmug.extvat.R;

public class FragmentHome extends Fragment {

    //
    GraphView graph;
    String locations[] = new String[]{"Kitchen","Living room","Laundry","Office","Bathroom","Ironing room","T.R.","P.R."}, stats[] = new String[]{"Temperature","Humidity","Cost"};
    Spinner locationSpinner, statSpinner;
    Context context;
    ProgressDialog progressDialog;

    TextView homeLocation, homeDate,configStatus, homeTemp, homeCost;

    AdapterView.OnItemSelectedListener listener1,listener2;

    @Override
    public void onAttach(final Context context) {
        super.onAttach(context);
        this.context = context;
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Loading data..");
        progressDialog.setCancelable(false);
        progressDialog.show();
        StringRequest str = new StringRequest(StringRequest.Method.GET, AppValues.HOME_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject object = new JSONObject(response);
                            homeLocation.setText(object.getString("location"));
                            homeDate.setText(object.getString("date"));

                            ArrayList<Float> points = new ArrayList<>();
                            for(int i=0;i<object.getJSONArray("energy_values").length();i++)
                            {
                                points.add(Float.parseFloat(object.getJSONArray("energy_values").getString(i)));
                            }
                            plotGraph(points);

                            if(object.getBoolean("optimization"))
                            {
                                configStatus.setText("YES");
                            }
                            else
                            {
                                configStatus.setText("NO");
                            }

                            changeRoom(0);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Toast.makeText(context,"Check network",Toast.LENGTH_SHORT).show();
                    }
                }
        ){

        };
        Log.i("Adding","request");
        Requestqueue.getmInstance(context.getApplicationContext()).addToRequestQueue(str);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view   = inflater.inflate(R.layout.fragment_home, container, false);
        graph       = view.findViewById(R.id.homeGraph);
        locationSpinner = view.findViewById(R.id.locationSpinner);
        homeLocation = view.findViewById(R.id.homeLocation);
        homeDate = view.findViewById(R.id.homeDate);
        configStatus = view.findViewById(R.id.configStatus);
        homeCost = view.findViewById(R.id.homeCost);
        homeTemp = view.findViewById(R.id.homeTemp);

        try {
            Field popup = Spinner.class.getDeclaredField("mPopup");
            popup.setAccessible(true);

            // Get private mPopup member variable and try cast to ListPopupWindow
            android.widget.ListPopupWindow popupWindow = (android.widget.ListPopupWindow) popup.get(locationSpinner);

            // Set popupWindow height to 500px
            popupWindow.setHeight(300);
        }
        catch (NoClassDefFoundError | ClassCastException | NoSuchFieldException | IllegalAccessException e) {
            // silently fail...
        }

        ArrayAdapter<String> locationAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_dropdown_item,locations);
        ArrayAdapter<String> statAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_dropdown_item, stats);
        locationSpinner.setAdapter(locationAdapter);
        //statSpinner.setAdapter(statAdapter);

        listener1 = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView)view).setTextColor(Color.WHITE);
                changeRoom(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        };
        listener2 = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView)view).setTextColor(Color.WHITE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        };
        locationSpinner.setOnItemSelectedListener(listener1);
        //statSpinner.setOnItemSelectedListener(listener2);

//        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(new DataPoint[] {
//                new DataPoint(0, 1),
//                new DataPoint(1, 5),
//                new DataPoint(2, 3),
//                new DataPoint(3, 2),
//                new DataPoint(4, 4),
//                new DataPoint(5,3),
//                new DataPoint(6,4),
//                new DataPoint(7,7)
//        });
//        series.setColor(getResources().getColor(R.color.colorAccent));
//        series.setDrawBackground(true);
//        series.setBackgroundColor(getResources().getColor(R.color.colorAccentOpaque));
//        series.setDrawDataPoints(true);
//        series.setDataPointsRadius(5);
//        graph.getGridLabelRenderer().setGridColor(Color.parseColor("#9e9e9e"));
//        graph.getGridLabelRenderer().setHorizontalLabelsColor(Color.parseColor("#9e9e9e"));
//        graph.getGridLabelRenderer().setVerticalLabelsColor(Color.parseColor("#9e9e9e"));
//        graph.addSeries(series);
        return view;
    }

    private void plotGraph(ArrayList<Float> points)
    {
        DataPoint[] dataPoints   = new DataPoint[points.size()];
        float max =0;
        for(int i=0;i<points.size();i++)
        {
            Log.i("Adding point",i+1+"---"+points.get(i));
            dataPoints[i]= new DataPoint(i,points.get(i));
            if(points.get(i)>max){max = points.get(i);}
        }
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(dataPoints);
        series.setColor(getResources().getColor(R.color.colorAccent));
        series.setDrawBackground(true);
        series.setBackgroundColor(getResources().getColor(R.color.colorAccentOpaque));
        series.setDrawDataPoints(true);
        series.setDataPointsRadius(5);
        graph.getGridLabelRenderer().setGridColor(Color.parseColor("#9e9e9e"));
        graph.getGridLabelRenderer().setHorizontalLabelsColor(Color.parseColor("#9e9e9e"));
        graph.getGridLabelRenderer().setVerticalLabelsColor(Color.parseColor("#9e9e9e"));
        graph.removeAllSeries();
        graph.getViewport().setYAxisBoundsManual(true);
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setMaxX(23);
        graph.getViewport().setMaxY((int)max+5);
        graph.addSeries(series);
    }

    private void changeRoom(int position)
    {
        StringRequest str = new StringRequest(StringRequest.Method.GET, AppValues.CHANGE_ROOM + "/" + position,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject object = new JSONObject(response);
                            homeCost.setText("$"+object.getString("cost"));
                            homeTemp.setText(object.getString("temperature")+"°C");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context,"Check network",Toast.LENGTH_SHORT).show();
                    }
                }
        ){

        };
        Requestqueue.getmInstance(context.getApplicationContext()).addToRequestQueue(str);
    }
}
