package in.wordmug.extvat.Activities;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Objects;

import in.wordmug.extvat.Constant.AppValues;
import in.wordmug.extvat.Constant.Requestqueue;
import in.wordmug.extvat.R;

public class FragmentAdmin extends android.support.v4.app.Fragment{


    ViewPager viewPager;
    PagerAdapter pagerAdapter;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_admin, container, false);
        viewPager = view.findViewById(R.id.adminPager);
        pagerAdapter = new PagerAdapter(Objects.requireNonNull(getActivity()).getSupportFragmentManager());
        pagerAdapter.addFragment(new FragmentPager());
        pagerAdapter.addFragment(new FragmentPager());
        pagerAdapter.addFragment(new FragmentPager());
        viewPager.setAdapter(pagerAdapter);

        return view;
    }

    private class PagerAdapter extends FragmentPagerAdapter
    {
        ArrayList<android.support.v4.app.Fragment> fragments = new ArrayList<>();
        ArrayList<String> titles = new ArrayList<>();

        public PagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public android.support.v4.app.Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titles.get(position);
        }

        public void addFragment(android.support.v4.app.Fragment fragment)
        {
            fragments.add(fragment);
            //titles.add(title);
        }
    }
}
