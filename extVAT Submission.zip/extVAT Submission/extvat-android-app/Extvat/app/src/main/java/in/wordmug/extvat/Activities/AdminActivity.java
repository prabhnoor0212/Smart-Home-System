package in.wordmug.extvat.Activities;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import in.wordmug.extvat.Constant.AppValues;
import in.wordmug.extvat.Constant.Requestqueue;
import in.wordmug.extvat.R;

public class AdminActivity extends AppCompatActivity {

    ViewPager viewPager;
    PagerAdapter adapter;
    ProgressDialog progressDialog;
    String COUNT_URL = "http://ec0b4b3f.ngrok.io/admin/check";

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case android.R.id.home: finish();
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        progressDialog = new ProgressDialog(this);

        //findCount();

        viewPager = findViewById(R.id.adminViewPager);
        adapter = new PagerAdapter(getSupportFragmentManager());

//        adapter.addFragment(new FragmentPager());
//        adapter.addFragment(new FragmentPager());
//        adapter.addFragment(new FragmentPager());
        for(int i=0;i<3;i++)
        {
            FragmentPager fragmentPager = new FragmentPager();
            Bundle bundle = new Bundle();
            bundle.putString("seq",String.valueOf(i+1));
            fragmentPager.setArguments(bundle);
            adapter.addFragment(fragmentPager);
        }

        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(2);
    }

    private class PagerAdapter extends FragmentPagerAdapter
    {
        ArrayList<Fragment> fragments = new ArrayList<>();
        ArrayList<String> titles = new ArrayList<>();

        public PagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public android.support.v4.app.Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titles.get(position);
        }

        public void addFragment(android.support.v4.app.Fragment fragment)
        {
            fragments.add(fragment);
            //titles.add(title);
        }
    }


    public void findCount(View view)
    {
        progressDialog.setMessage("Please wait");
        progressDialog.setCancelable(false);
        progressDialog.show();
        StringRequest str = new StringRequest(StringRequest.Method.GET, COUNT_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.hide();
                        try {
                            JSONObject object = new JSONObject(response);
                            if(object.getBoolean("status"))
                            {
                                AlertDialog.Builder builder = new AlertDialog.Builder(AdminActivity.this);
                                builder.setMessage("Temperatures of " + object.getString("number") + " HVACS systems were reduced by 1 degree Celsius. Want to revert?");
                                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        Toast.makeText(AdminActivity.this,"Values were optimised",Toast.LENGTH_SHORT).show();
                                    }
                                });
                                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {


                                    }
                                });
                                builder.show();
                            }
                            else
                            {
                                AlertDialog.Builder builder = new AlertDialog.Builder(AdminActivity.this);
                                builder.setMessage("Required optimization was not possible");
                                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                    }
                                });
                                builder.show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.hide();
                        Toast.makeText(AdminActivity.this,"Check network",Toast.LENGTH_SHORT).show();
                    }
                }
        ){

        };
        Requestqueue.getmInstance(getApplicationContext()).addToRequestQueue(str);
    }


}
